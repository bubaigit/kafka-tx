package com.test.transaction.demo;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TestPublisher {

    @Value(value = "${raw.topic.name}")
    private String testTopic;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private static final String TEST_DATA = "My test Message";

    //@Transactional
    public void publishTestMessage() {
        ProducerRecord<String, String> pr = new ProducerRecord<String, String>(testTopic, "TestKey-001", TEST_DATA);
        //this.kafkaTemplate.send(pr);
        this.kafkaTemplate.executeInTransaction(
                kt-> {
                    kt.send(pr);
                    return true;
                }
        );
    }
}
