package com.test.transaction.demo;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Configuration
@Slf4j

public class ConsumerService {

    @Value(value = "${inventory.topic.name}")
    private String inventoryTopic;
    @Value(value = "${price.topic.name}")
    private String priceTopic;
    @Value(value = "${item.topic.name}")
    private String itemTopic;
    @Autowired
    private ProducerService producerService;


    @KafkaListener(topics = "${raw.topic.name}")
    //@Transactional
    public void receive(ConsumerRecord<String, String> cr ) throws Exception {
        log.info("Consumer Service received payload. key :{} , value : {}", cr.key() , cr.value());
        splitRawItemAndPost(cr.value());
    }

    private void splitRawItemAndPost(String consumerData) {
        ProducerRecord<String,String> itemRecord = getItemData(consumerData);
        ProducerRecord<String,String> InventoryRecord = getInventoryData(consumerData);
        ProducerRecord<String,String> priceRecord = getPriceData(consumerData);

        producerService.sendAllRecords(itemRecord,InventoryRecord,priceRecord);

    }


    private ProducerRecord<String, String> getItemData(String consumerData) {
        String data = "Item data : " + consumerData;
        ProducerRecord<String,String> producerRecord= buildProducerRecord(itemTopic,"ItemId-001",data);
        return producerRecord;
    }

    private ProducerRecord<String, String> getInventoryData(String consumerData){
        String data = "Inventory data : "+ consumerData;
        ProducerRecord<String,String> producerRecord= buildProducerRecord(inventoryTopic,"InventoryId-001", data);
        return producerRecord;
    }

    private ProducerRecord<String, String> getPriceData(String consumerData) {
        //String data = "This is Price data";
        //ProducerRecord<String,String> producerRecord= buildProducerRecord(priceTopic,"PriceId-001", data);
        String data = new String(new byte[2000000]) + consumerData; // Very Large Data
        ProducerRecord<String,String> producerRecord= buildProducerRecord(priceTopic,"PriceId-001", data);
        return producerRecord;
    }

    private ProducerRecord<String, String> buildProducerRecord(String topic, String key,String value) {
        return new ProducerRecord<String, String>(topic,key,value);
    }
}
