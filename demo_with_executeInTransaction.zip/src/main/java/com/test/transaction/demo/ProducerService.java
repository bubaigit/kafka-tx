package com.test.transaction.demo;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Configuration
@Slf4j
public class ProducerService {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendAllRecords(ProducerRecord<String, String> item, ProducerRecord<String, String> inventory,
                               ProducerRecord<String, String> price){

        log.info("--- Sending Data to  Item , price, Inventory  -----");
        /*this.kafkaTemplate.send(item);
        this.kafkaTemplate.send(inventory);
        this.kafkaTemplate.send(price);*/
        try {
            this.kafkaTemplate.executeInTransaction(
                    kt ->
                    {
                        kt.send(item);
                        kt.send(inventory);
                        kt.send(price);
                        return null;
                    }
            );

        }catch (Exception ex){
            throw ex;
        }
    }
}
