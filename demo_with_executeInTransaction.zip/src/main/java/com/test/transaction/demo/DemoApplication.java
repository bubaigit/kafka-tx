package com.test.transaction.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
//@EnableTransactionManagement
public class DemoApplication {
    @Autowired
    TestPublisher testPublisher;

    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(DemoApplication.class, args);
        //Thread.sleep(5000);


    }

    @Bean
    ApplicationRunner runner() {
        return args -> testPublisher.publishTestMessage();
    }

}
